package com.example.game1;

import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.scene.menu.MenuScene;
import org.andengine.entity.scene.menu.MenuScene.IOnMenuItemClickListener;
import org.andengine.entity.scene.menu.item.IMenuItem;
import org.andengine.entity.scene.menu.item.SpriteMenuItem;

import android.opengl.GLES20;
import android.view.KeyEvent;

import com.example.game1.SceneManager.SceneType;
import com.example.game1.StateManager.StateType;

public class MenuState extends State {

    //Menu indices
    public static final int MENU_PLAY = 0;
	public static final int MENU_QUIT = MENU_PLAY + 1;
	
	public MenuState(MainActivity activityReference) {
		super(activityReference);
		
		//menu scene
    	Scene menuScene = new Scene();
    	menuScene.setBackground(new Background(0.0f, 1.0f, 0.0f));
    	SceneManager.getInstance().addScene(SceneType.MENU, menuScene);
    	
    	MenuScene menuOptionsScene = createMenuOptionsScene();
    	menuScene.setChildScene(menuOptionsScene, false, true, true);
    	
	}
	
	private MenuScene createMenuOptionsScene() {
		MenuScene menuOptionsScene = new MenuScene(EngineOptionsManager.getInstance().getCamera());

		final SpriteMenuItem resetMenuItem = new SpriteMenuItem(MENU_PLAY, ResourceManager.getInstance().mMenuPlayTextureRegion, activityReference.getVertexBufferObjectManager());
		resetMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
		menuOptionsScene.addMenuItem(resetMenuItem);

		final SpriteMenuItem quitMenuItem = new SpriteMenuItem(MENU_QUIT, ResourceManager.getInstance().mMenuQuitTextureRegion, activityReference.getVertexBufferObjectManager());
		quitMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
		menuOptionsScene.addMenuItem(quitMenuItem);

		menuOptionsScene.buildAnimations();

		menuOptionsScene.setBackgroundEnabled(false);

		menuOptionsScene.setOnMenuItemClickListener(this);
		
		return menuOptionsScene;
	}
	
	@Override
	public void initialize() {
		this.sceneType = SceneType.MENU;
	}
	
	@Override
	public void begin() {
		ResourceManager.getInstance().playMenuMusic();
	}
	
	@Override
	public void end() {
		ResourceManager.getInstance().stopMenuMusic();
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
    	if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)
    	{
    		processBackButton();	
    	}
		
		return true;
	}
	
	private void processBackButton() {

		StateManager.getInstance().switchState(StateType.OPTIONS);

    }

    @Override
	public boolean onMenuItemClicked(final MenuScene pMenuScene, final IMenuItem pMenuItem, final float pMenuItemLocalX, final float pMenuItemLocalY) {
		
    	switch(pMenuItem.getID()) {
			case MENU_PLAY:
				// Restart the animation.
				/*
				this.mMainScene.reset();

				// Remove the menu and reset it.
				this.mMainScene.clearChildScene();
				this.mMenuScene.reset();
				*/
				return true;
			case MENU_QUIT:
				// End Activity.
				activityReference.finish();
				return true;
			default:
				return false;
		}
    }
	
}


