package com.example.game1;

import java.util.HashMap;
import java.util.Map;

import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.scene.menu.MenuScene;
import org.andengine.entity.scene.menu.item.SpriteMenuItem;

import com.example.game1.StateManager.StateType;

import android.opengl.GLES20;

public class SceneManager {
	
	private static SceneManager instance;
	
	public static void initializeSceneManager(MainActivity activityReference) {
		if (instance == null) {
			instance = new SceneManager(activityReference);
		}	
	}
	
	public static synchronized SceneManager getInstance() {
		return instance;
	}
	
	private MainActivity activityReference;
	
	//access the application
	public MainActivity getActivityReference() {
		return this.activityReference;
	}
	
    //Scene types
    public enum SceneType
    {
    	NONE,
    	SPLASH,
    	MENU,
    	OPTIONS,
    	GAME    	
    }
    
    //Our current scene
    private SceneType currentScene = SceneType.SPLASH;
    
    //Our scene container
    private Map<SceneType, Scene> sceneMap;
    
    private void initializeScenes() {
    }
    
    public void addScene(SceneType sceneType, Scene scene) {
    	sceneMap.put(sceneType, scene);
    }
    
    //Constructor
    private SceneManager(MainActivity activityReference) {
    	sceneMap = new HashMap<SceneType, Scene>();
    	this.activityReference = activityReference;
    	initializeScenes();
    }
    
    public Scene getScene(SceneType sceneType) {
    	return sceneMap.get(sceneType);
    }
	
}



